﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Caching;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int n;

        if (ViewState["vsn"] == null)
            n = 0;
        else
            n = Convert.ToInt32(ViewState["vsn"]);
        ViewState["vsn"]=++n;
        Label2.Text = n.ToString();

        DataView dv=Cache["product"] as DataView;
        if (dv == null)
        {
            DataSourceSelectArguments args = new DataSourceSelectArguments();
            dv = SqlDataSource1.Select(args) as DataView;
                        
            Label1.Text = "New Data fetched";

            CacheDependency cd = new CacheDependency(Server.MapPath("TextFile.txt"));
            Cache.Insert("product", dv, null,DateTime.Now.AddSeconds(10),TimeSpan.Zero);

            //FileStream fs = new FileStream("TextFile.txt", FileMode.Open, FileAccess.Read);

            StreamReader sr = new StreamReader(Server.MapPath("TextFile.txt"));
            Label1.Text += "<br/>" + sr.ReadToEnd();
            
        }
        else
            Label1.Text = " Data fetched from cache";

        GridView1.DataBind();

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Cache.Remove("product");
    }
}